#!/bin/bash

name="Mustafa Berke"
surname="Celiker"
doc="me.txt"

# Writing into the doc
echo "NAME: $name" > "$doc"
echo "SURNAME: $surname" >> "$doc"

# İnfo messages
echo "Document created successfully: $doc"
echo "Content of Document:"
cat "$doc"
